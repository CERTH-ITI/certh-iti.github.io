#include <opencv2/opencv.hpp>
#include "boost/python.hpp"


class certh_face_dlib
{
public:
    certh_face_dlib();
    ~certh_face_dlib();

    void setKnownPeopleDir(std::string& dir);
    void setPYTHONPATH(std::string path);
    std::vector<float> recognizePerson(cv::Mat& inputImg);
    std::vector<float> recognizePerson(std::string& img);
    std::vector<std::string> getLabels();


private:
    std::vector< std::string > known_people_labels_;
    boost::python::object python_FR_;
};
