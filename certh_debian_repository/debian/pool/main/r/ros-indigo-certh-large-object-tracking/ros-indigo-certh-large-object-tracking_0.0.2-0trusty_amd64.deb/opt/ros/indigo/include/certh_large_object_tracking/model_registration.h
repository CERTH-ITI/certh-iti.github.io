#ifndef MODEL_REGISTRATION_H
#define MODEL_REGISTRATION_H

#include <Eigen/Geometry>
#include <Eigen/Core>

#include <iostream>
#include <vector>
#include <fstream>
#include <cstring>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <pcl/common/common.h>
#include <pcl/registration/icp.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/common/time.h>
#include <pcl/features/normal_3d_omp.h>

#include <pcl/keypoints/uniform_sampling.h>
#include <pcl/features/normal_3d.h>
#include <pcl/features/fpfh.h>
#include <pcl/registration/correspondence_estimation.h>
#include <pcl/registration/correspondence_rejection_distance.h>
#include <pcl/registration/transformation_estimation_svd.h>
//#include <pcl/visualization/pcl_visualizer.h>

#include <geometry_msgs/Pose.h>

#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>

#include <opencv2/opencv.hpp>

#include "constrainedsvd.h"
#include "constrainedp2plls.h"

#include <sensor_msgs/CameraInfo.h>
#include <certh_renderer/Renderer.h>

struct model_part {
    std::string name ;
    std::string path ;
    std::string parent ;
    std::string state ;
    std::string joint_type ;
    std::string joint_axis ;
    std::string rotation_direction ;
    std::vector<float> joint_limits ;
    std::vector<int> part_children ;
    geometry_msgs::Pose pivot_point ;
    float offset ;
    bool alligned ;

    Eigen::Affine3f part_tf ;

    geometry_msgs::Pose part_pose ;
    geometry_msgs::Pose init_part_pose ;

    pcl::PointCloud<pcl::PointXYZRGBNormal> prt_cloud ;
    pcl::PointCloud<pcl::PointXYZRGB> prt_cloud_init ;

};

struct model {
    std::vector<model_part> parts ;
    std::string name ;
    std::vector<std::pair<int, std::vector<int> > > map_children ;
    geometry_msgs::Pose fixedRobotPose ;
};


struct Intrinsics {
    double fx ;
    double fy ;
    double cx ;
    double cy ;
    double resx ;
    double resy ;
};

class model_registration
{
public:
    model_registration();
    model_registration(std::vector<int> ids, sensor_msgs::CameraInfo cam, std::string &model_path, int &numofiterations, float &max_distance_for_corr) ;
    void register_base(cv::Mat &rgb, cv::Mat &depth, pcl::PointCloud<pcl::PointXYZRGB> &cloud, geometry_msgs::Pose camera_pose, std::vector <geometry_msgs::Pose> &fixed_poses, std::vector< float> &poses_conf) ;
    bool register_parts(cv::Mat &rgb, cv::Mat &depth, pcl::PointCloud<pcl::PointXYZRGB> &cloud, geometry_msgs::Pose camera_pose) ;
    bool track_part(model &model_, int index) ;
    bool model_registration_init(std::vector<int> ids) ;
    bool tracking (pcl::PointCloud<pcl::PointXYZRGB> &cloudIn, std::vector<pcl::PointCloud<pcl::PointXYZRGBNormal> > &cloudOut, std::vector<std::string> &state, std::vector<std::string> &offset) ;
    //  std::vector<std::pair<geometry_msgs::Pose, double> > register_model(std::vector<int> ids, pcl::PointCloud<pcl::PointXYZRGB>::Ptr cloud) ;
    //  std::vector<model> register_model_RT(std::vector<int> ids, cv::Mat &rgb, cv::Mat &depth, pcl::PointCloud<pcl::PointXYZRGB> &cloud, geometry_msgs::Pose &cam, int flag) ;
    Eigen::Matrix4f register_model_RT(int curr_id, cv::Mat &rgb, cv::Mat &depth, pcl::PointCloud<pcl::PointXYZRGB> &cloud, geometry_msgs::Pose camera_pose, int ref_flag) ;
    bool tracker(int j) ;
    geometry_msgs::Pose eigenPoseToROSf(const Eigen::Vector3f &pos, const Eigen::Quaternionf &orient) ;
    geometry_msgs::Pose eigenToPosef(const Eigen::Affine3f &pose_) ;
    Eigen::Affine3f poseToEigenf(const geometry_msgs::Pose &pose) ;
    geometry_msgs::Pose eigenPoseToROSd(const Eigen::Vector3d &pos, const Eigen::Quaterniond &orient) ;
    geometry_msgs::Pose eigenToPosed(const Eigen::Affine3d &pose_) ;
    Eigen::Affine3d poseToEigend (const geometry_msgs::Pose &pose) ;
    pcl::PointCloud<pcl::PointXYZRGB> render_model (model &model_, int index) ;
    //boost::shared_ptr<pcl::visualization::PCLVisualizer> viewRefinement (pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr before, pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr after, pcl::PointCloud<pcl::PointXYZRGB>::ConstPtr model) ;

    //private:

    std::vector<std::pair<geometry_msgs::Pose, std::string> > poses_ ;
    std::vector<int> ids_ ;
    pcl::PointCloud<pcl::PointXYZRGB> cloud_ ;
    boost::filesystem::path model_path_ ;
    //  std::vector<std::pair <pcl::PointCloud<pcl::PointXYZRGB>, std::string > >  modelsfull_ ;
    std::vector< model > modelsRT_ ;
    Intrinsics cam_model_ ;
    Eigen::Matrix4f vtkcamtransform_ ;
    geometry_msgs::Pose camera_pose_ ;
    Eigen::Affine3f camera_mtx_ ;
    cv::Mat rgb_ ;
    cv::Mat depth_ ;
    std::vector<int> alligned_ ;
    int reg_flag_ ;
    int counter_ ;
    int num_of_iterations_;
    float max_distance_for_corr_;

    std::string ramcip_setup;

    certh_core::PinholeCamera *cam_ ;

    void depthToPointCloud(const cv::Mat &rgb, const cv::Mat &depth, pcl::PointCloud<pcl::PointXYZRGB> &cloud) ;
    //  Eigen::Matrix4f register_w_fpfh(pcl::PointCloud<pcl::PointXYZRGB>::Ptr src, pcl::PointCloud<pcl::PointXYZRGB>::Ptr target) ;

    //  cv::Mat render_edges (std::vector<vtkSmartPointer<vtkActor> > actors) ;
    //  Eigen::Matrix4f register_edges (cv::Mat &scene, cv::Mat &obj) ;

    std::vector<std::string> read_params_ (std::string path) ;
    model load_model (std::string model_name) ;

    //  std::pair<geometry_msgs::Pose, double> fix_robot_pose_(std::pair<pcl::PointCloud<pcl::PointXYZRGB>, std::string> &model) ;
    void update_part_children(Eigen::Affine3f &tf,  int id, model &model_) ;
    bool apply_icp(model &model_, int index) ;
    void apply_icpToBase (model &model_, int index, geometry_msgs::Pose &fixed_pose, float &poses_conf) ;
    bool apply_icpTopart (model &model_, int index) ;
    void find_bounding_box_ (pcl::PointCloud<pcl::PointXYZRGB> &cloud) ;

};

#endif // MODEL_REGISTRATION_H
