#ifndef CONSTRAINEDSVD_HPP_
#define CONSTRAINEDSVD_HPP_

#include <pcl/common/eigen.h>
#include <pcl/cloud_iterator.h>
#include <pcl/registration/transformation_estimation.h>

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> inline void
ConstrSVD<PointSource, PointTarget, Scalar>::estimateRigidTransformation (
    const pcl::PointCloud<PointSource> &cloud_src,
    const pcl::PointCloud<PointTarget> &cloud_tgt,
    Matrix4 &transformation_matrix) const
{
  size_t nr_points = cloud_src.points.size ();
  if (cloud_tgt.points.size () != nr_points)
    {
      PCL_ERROR ("[pcl::TransformationEstimationSVD::estimateRigidTransformation] Number or points in source (%lu) differs than target (%lu)!\n", nr_points, cloud_tgt.points.size ());
      return;
    }

  pcl::ConstCloudIterator<PointSource> source_it (cloud_src);
  pcl::ConstCloudIterator<PointTarget> target_it (cloud_tgt);
  estimateRigidTransformation (source_it, target_it, transformation_matrix);
}

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> void
ConstrSVD<PointSource, PointTarget, Scalar>::estimateRigidTransformation (
    const pcl::PointCloud<PointSource> &cloud_src,
    const std::vector<int> &indices_src,
    const pcl::PointCloud<PointTarget> &cloud_tgt,
    Matrix4 &transformation_matrix) const
{
  if (indices_src.size () != cloud_tgt.points.size ())
    {
      PCL_ERROR ("[pcl::TransformationSVD::estimateRigidTransformation] Number or points in source (%lu) differs than target (%lu)!\n", indices_src.size (), cloud_tgt.points.size ());
      return;
    }

  pcl::ConstCloudIterator<PointSource> source_it (cloud_src, indices_src);
  pcl::ConstCloudIterator<PointTarget> target_it (cloud_tgt);
  estimateRigidTransformation (source_it, target_it, transformation_matrix);
}

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> inline void
ConstrSVD<PointSource, PointTarget, Scalar>::estimateRigidTransformation (
    const pcl::PointCloud<PointSource> &cloud_src,
    const std::vector<int> &indices_src,
    const pcl::PointCloud<PointTarget> &cloud_tgt,
    const std::vector<int> &indices_tgt,
    Matrix4 &transformation_matrix) const
{
  if (indices_src.size () != indices_tgt.size ())
    {
      PCL_ERROR ("[pcl::TransformationEstimationSVD::estimateRigidTransformation] Number or points in source (%lu) differs than target (%lu)!\n", indices_src.size (), indices_tgt.size ());
      return;
    }

  pcl::ConstCloudIterator<PointSource> source_it (cloud_src, indices_src);
  pcl::ConstCloudIterator<PointTarget> target_it (cloud_tgt, indices_tgt);
  estimateRigidTransformation (source_it, target_it, transformation_matrix);
}

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> void
ConstrSVD<PointSource, PointTarget, Scalar>::estimateRigidTransformation (
    const pcl::PointCloud<PointSource> &cloud_src,
    const pcl::PointCloud<PointTarget> &cloud_tgt,
    const pcl::Correspondences &correspondences,
    Matrix4 &transformation_matrix) const
{
  pcl::ConstCloudIterator<PointSource> source_it (cloud_src, correspondences, true);
  pcl::ConstCloudIterator<PointTarget> target_it (cloud_tgt, correspondences, false);
  estimateRigidTransformation (source_it, target_it, transformation_matrix);
}

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> inline void
ConstrSVD<PointSource, PointTarget, Scalar>::estimateRigidTransformation (
    pcl::ConstCloudIterator<PointSource>& source_it,
    pcl::ConstCloudIterator<PointTarget>& target_it,
    Matrix4 &transformation_matrix) const
{
  // Convert to Eigen format
  const int npts = static_cast <int> (source_it.size ());



  //  if (use_umeyama_)
  //  {
  //    Eigen::Matrix<Scalar, 3, Eigen::Dynamic> cloud_src (3, npts);
  //    Eigen::Matrix<Scalar, 3, Eigen::Dynamic> cloud_tgt (3, npts);

  //    for (int i = 0; i < npts; ++i)
  //    {
  //      cloud_src (0, i) = source_it->x;
  //      cloud_src (1, i) = source_it->y;
  //      cloud_src (2, i) = source_it->z;
  //      ++source_it;

  //      cloud_tgt (0, i) = target_it->x;
  //      cloud_tgt (1, i) = target_it->y;
  //      cloud_tgt (2, i) = target_it->z;
  //      ++target_it;
  //    }

  //    // Call Umeyama directly from Eigen (PCL patched version until Eigen is released)
  ////    transformation_matrix = pcl::umeyama (cloud_src, cloud_tgt, false);
  //  }
  //  else
  //  {
  source_it.reset (); target_it.reset ();
  // <cloud_src,cloud_src> is the source dataset
  transformation_matrix.setIdentity ();

  Eigen::Matrix<Scalar, 4, 1> centroid_src, centroid_tgt;
  // Estimate the centroids of source, target
  compute3DCentroid (source_it, centroid_src);
  compute3DCentroid (target_it, centroid_tgt);
  source_it.reset (); target_it.reset ();

  // Subtract the centroids from source, target
  Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> cloud_src_demean, cloud_tgt_demean;
  demeanPointCloud (source_it, centroid_src, cloud_src_demean);
  demeanPointCloud (target_it, centroid_tgt, cloud_tgt_demean);

  getTransformationFromCorrelation (cloud_src_demean, centroid_src, cloud_tgt_demean, centroid_tgt, transformation_matrix);

  //   std::cout << transformation_matrix << std::endl ;
  //  }
}

///////////////////////////////////////////////////////////////////////////////////////////
template <typename PointSource, typename PointTarget, typename Scalar> void
ConstrSVD<PointSource, PointTarget, Scalar>::getTransformationFromCorrelation (
    const Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> &cloud_src_demean,
    const Eigen::Matrix<Scalar, 4, 1> &centroid_src,
    const Eigen::Matrix<Scalar, Eigen::Dynamic, Eigen::Dynamic> &cloud_tgt_demean,
    const Eigen::Matrix<Scalar, 4, 1> &centroid_tgt,
    Matrix4 &transformation_matrix) const
{
  transformation_matrix.setIdentity ();

  // Assemble the correlation matrix H = source * target'
  Eigen::Matrix<Scalar, 3, 3> H = (cloud_src_demean * cloud_tgt_demean.transpose ()).topLeftCorner (3, 3);

  // Compute the Singular Value Decomposition
  Eigen::JacobiSVD<Eigen::Matrix<Scalar, 3, 3> > svd (H, Eigen::ComputeFullU | Eigen::ComputeFullV);
  Eigen::Matrix<Scalar, 3, 3> u = svd.matrixU ();
  Eigen::Matrix<Scalar, 3, 3> v = svd.matrixV ();

  // Compute R = V * U'
  if (u.determinant () * v.determinant () < 0)
    {
      for (int x = 0; x < 3; ++x)
        v (x, 2) *= -1;
    }

  Eigen::Matrix<Scalar, 3, 3> R = v * u.transpose ();

  // Return the correct transformation
  transformation_matrix.topLeftCorner (3, 3) = R;
  const Eigen::Matrix<Scalar, 3, 1> Rc (R * centroid_src.head (3));
  transformation_matrix.block (0, 3, 3, 1) = centroid_tgt.head (3) - Rc;

  double thx = atan2(transformation_matrix(2,1),transformation_matrix(2,2));
  double thy = atan2(-transformation_matrix(2,0),sqrt(pow(transformation_matrix(2,1),2) + pow(transformation_matrix(2,2),2)));
  double thz = atan2(transformation_matrix(1,0),transformation_matrix(0,0));
  double x = transformation_matrix(0,3);
  double y = transformation_matrix(1,3);
  double z = transformation_matrix(2,3);

  Eigen::Matrix4f transf_mat ;

  if (joint_type_ == "revolute") {
      if (transf_axis_ == "x") {

          if ((thx >= min_)&&(thx <= max_)) {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 , cos(thx)  ,   -sin(thx), 0,
                  0 , sin(thx) ,   cos(thx), 0,
                  0 ,        0  ,          0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
      else if (transf_axis_ == "y") {

          if ((thy >= min_)&&(thy <= max_)) {
              transf_mat << cos(thy) , 0  ,  sin(thy), 0,
                  0 , 1  ,         0, 0,
                  -sin(thy), 0  ,  cos(thy), 0,
                  0 , 0  ,         0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
      else if (transf_axis_ == "z"){

          if ((thz >= min_)&&(thz <= max_)) {
              transf_mat << cos(thz) , -sin(thz)  ,  0, 0,
                  sin(thz) , cos(thz)  ,  0, 0,
                  0 ,        0  ,  1, 0,
                  0 ,        0  ,  0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
    }
  else if (joint_type_ == "prismatic") {
      if (transf_axis_ == "x") {

          if ((x >= min_)&&(x <= max_)) {
              transf_mat << 1 ,        0  ,          0, x,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
      else if (transf_axis_ == "y") {

          if ((y >= min_)&&(y <= max_)) {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, y,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
      else {

          if ((z >= min_)&&(z <= max_)) {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, z,
                  0 ,        0  ,          0, 1;
            }
          else {
              transf_mat << 1 ,        0  ,          0, 0,
                  0 ,        1  ,          0, 0,
                  0 ,        0  ,          1, 0,
                  0 ,        0  ,          0, 1;
            }

        }
    }

  else if (joint_type_ == "spherical") {


      transf_mat = transformation_matrix ;

      transf_mat(0,3) = 0 ;
      transf_mat(1,3) = 0 ;
      transf_mat(2,3) = 0 ;

    }

  else if (joint_type_ == "universal") {
      transf_mat << cos(thz) , -sin(thz) ,  0, x,
          sin(thz) , cos(thz)  ,  0, y,
          0        ,        0  ,  1, 0,
          0        ,        0  ,  0, 1;
    }


  transformation_matrix = transf_mat ;

}


#endif /* PCL_REGISTRATION_TRANSFORMATION_ESTIMATION_SVD_HPP_ */

