#ifndef __FACE_LANDAMRK_DETECTOR_H__
#define __FACE_LANDAMRK_DETECTOR_H__

#include <certh_core/Point2D.h>
#include <certh_core/BinaryStream.h>

#include <certh_core/RandomForest.h>

#include <string>
#include <boost/filesystem.hpp>

#include <certh_face/AnnotatedDataset.h>

namespace certh_face {

namespace rf {

// An implementation of the facial landmark detector proposed in
//
// Robust and Accurate Shape Model Fitting Using Random Forest Regression Voting, Tim F. Cootes, Mircea C. Ionita, Claudia Lindner, Patrick Sauer, ECCV 2012
//
// The regressor features are different from those discribed in the paper. Namely for each node we operate randomly in two modes. The first mode computes Haar like
// features within the patch while in the second mode a random displacement relative to the patch is generated and the Haar feature is computed between pixels in the
// original patch and those in the displaced patch.
// Also the shape model has a robust fitting step that performs weighted least squares fitting of landmarks. The weights are inversely proportional to the regressor
// responses i.e. weak responses are not considered.

class FacialLandmarkDetectorImpl ;

class FacialLandmarkDetector {
public:

    struct TrainingParameters {

        enum Channels { GrayscaleChannel = 0x1, GaborChannel = 0x2, SobelChannel = 0x4 } ;

        TrainingParameters():
            face_box_border(0.2),
            scale_perturbation(0.05),
            rotation_perturbation(M_PI/120.0),
            face_width(120),
            patch_size(32),
            patch_offset(12),
            patches_per_landmark(100),
            num_perturbations(10),
            channels( GrayscaleChannel /*| SobelChannel | GaborChannel */),
            use_integral_images(true),
            max_training_exemplars(150)
            {
                rf_params.gain_threshold = 0.01 ;
                rf_params.max_depth = 15 ;
                rf_params.min_pts_per_leaf = 20 ;
                rf_params.num_random_samples = 1000 ;
                rf_params.num_trees = 10 ;
                rf_params.num_samples_per_tree = 25000 ;
                rf_params.num_thresholds_per_sample = 20 ;
            }

        // serialize the parameters together with the trained forest
        void read(certh_core::BinaryStream &str) ;
        void write(certh_core::BinaryStream &str) const ;

        uint32_t num_perturbations ;    // number of rotation and scale perturbations to simulate
        float scale_perturbation ;      // percentage of scale perturbation
        float rotation_perturbation ;   // degress of rotation perturbation

        float face_box_border ;    // border around detected window as percentage of original box
        uint32_t face_width ;  // common face size to scale all images
        uint32_t channels ;        // a bit field containing the channels that will be computed on each training image
        uint32_t patch_size ;     // size of each patch
        uint32_t patch_offset ;   // range for training patches around each landmark
        uint32_t patches_per_landmark ; // number of patches to sample around each landmark
        bool use_integral_images ;
        uint32_t num_thresholds_per_split_test ; // number of threshold to test for every split test
        uint32_t max_training_exemplars ; // do not load more annotated samples than this
        certh_core::RFTrainingParameters rf_params ;
    };

    FacialLandmarkDetector() {}

    // train the regression forest and shape model and write training data to a single outout file

    bool train(const AnnotatedDataset &ds, const TrainingParameters &params,
               const boost::filesystem::path &outPath) ;

    // load the model from disk
    bool load_model(const boost::filesystem::path &dataFolder) ;

    struct DetectionParameters {

        DetectionParameters():
            search_offset(16), search_step(2), search_radius(16), max_iterations(10) {}

        uint8_t search_offset ; // range around each landmark to sample image patches
        uint8_t search_step ; // step size of patch generation
        uint8_t search_radius ; // the radius around each landmark used to search the corresponding hough image for a maximum
        uint8_t max_iterations ; // maximum number of iterations

    };

    // detect landmarks within the face box
    double detect(const cv::Mat &im, const cv::Rect &face_box, const DetectionParameters &params, PointList2d &pts) ;

private:

    boost::shared_ptr<FacialLandmarkDetectorImpl> impl_ ;

    void regression(const cv::Mat &im, const PointList2d &cp, double r, double tx, double ty, PointList2d &pts, Eigen::VectorXd &scores);
};

}

} // namespace face


#endif
