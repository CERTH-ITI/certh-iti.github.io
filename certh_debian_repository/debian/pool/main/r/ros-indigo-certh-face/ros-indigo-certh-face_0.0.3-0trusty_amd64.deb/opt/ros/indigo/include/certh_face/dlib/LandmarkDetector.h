#ifndef __DLIB_LANDMARK_DETECTOR_H__
#define __DLIB_LANDMARK_DETECTOR_H__

#include <boost/filesystem.hpp>
#include <boost/shared_ptr.hpp>
#include <certh_core/PointList2D.h>
#include <certh_core/Calibration.h>

class FacialLandmarkDetectorImpl ;

namespace certh_face {
namespace dlib {

// wrapper around dlib facial landmark detector

class FacialLandmarkDetector {

public:

    FacialLandmarkDetector() ;

    // init with the training data file downloaded from:
    // http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2

    bool init(const boost::filesystem::path &p) ;

    // detect landmarks on image roi

    bool detect(const cv::Mat &im, const cv::Rect &r, certh_core::PointList2d &pts) ;

    // Warps image and detected points. The affine transform between the points and the average face is estimated.
    // The final image has size (sz). The face is translated vertically so that the interocular point is (offset) pixels
    // from the top of the frame. An additional padding may be used.
    cv::Mat align(const cv::Mat &src, certh_core::PointList2d &pts, const cv::Size &sz, uint offset, uint padding) ;

    // same as above but non-rigid warping is used (thin plate spline)
    cv::Mat align_tps(const cv::Mat &src, const certh_core::PointList2d &pts, uint sz, uint offset, uint padding, float lambda) ;

    // draw result

    void draw(cv::Mat &im, const certh_core::PointList2d &pts) ;

    // estimate pose using POSIT algorithm

     bool estimatePose(const certh_core::PointList2d &pts, const certh_core::PinholeCamera &cam, Eigen::Affine3d &a) ;

private:

    boost::shared_ptr<FacialLandmarkDetectorImpl> pimpl_ ;


};

}
}
#endif
