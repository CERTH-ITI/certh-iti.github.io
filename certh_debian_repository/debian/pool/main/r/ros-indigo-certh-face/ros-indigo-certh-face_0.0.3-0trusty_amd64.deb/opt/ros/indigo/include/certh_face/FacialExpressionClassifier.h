#ifndef __CERTH_FACE_FACIAL_EXPRESSIONS_CLASSIFIER_H__
#define __CERTH_FACE_FACIAL_EXPRESSIONS_CLASSIFIER_H__

#include <boost/filesystem.hpp>
#include <boost/shared_ptr.hpp>
#include <Eigen/Core>
#include <opencv2/opencv.hpp>

#include <certh_core/PointList2D.h>

namespace certh_face {

// Facial Action Unit classifier based on LGBP histogram features and binary SVM classifier for each AU/expression

class FacialExpressionClassifier {
public:

    struct Parameters {

    };

    FacialExpressionClassifier() {}
    FacialExpressionClassifier(const Parameters &params): params_(params) {}

    // load training data from file.
    // attr is a list of classes to recognize in the form "AU1+AU2+AU4+AU12"
    bool init(const boost::filesystem::path &p, const std::string &attr) ;

    // classify sample to one of trained classed; return true for positive and false for negative
    bool classify(const cv::Mat &im, const certh_core::PointList2d &pts, const std::string &className) ;

private:

    Parameters params_ ;

    struct Subspace {
        Eigen::MatrixXf U_ ;
        Eigen::VectorXf M_, L_ ;
    };

    struct SVMData {
        boost::shared_ptr<CvSVM> svm_ ; // binary classifier
        Eigen::MatrixXf M_, V_ ; //mean and variance for normalization
        std::string feature_ ;
    };

    std::map<std::string, Subspace> subspaces_ ;
    std::map<std::string, SVMData> classifiers_ ;

};


}
#endif
