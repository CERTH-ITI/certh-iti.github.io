#ifndef __DLIB_FACE_DETECTOR_H__
#define __DLIB_FACE_DETECTOR_H__

#include <boost/filesystem.hpp>
#include <boost/shared_ptr.hpp>
#include <opencv2/opencv.hpp>

class FaceDetectorImpl ;

namespace certh_face {
namespace dlib {

// wrapper around dlib face detector

class FaceDetector {

public:

    struct Parameters {

    };

    FaceDetector() ;

    bool init(const Parameters &params) ;

    // detect faces optionally providing a search ROI
    bool detect(const cv::Mat &im, std::vector<cv::Rect> &faces, const cv::Rect &roi = cv::Rect()) ;

    // same as above but return largest face
    bool detect(const cv::Mat &im, cv::Rect &faces, const cv::Rect &roi = cv::Rect()) ;

    // draw detected faces
    void draw(cv::Mat &im, const std::vector<cv::Rect> &faces, const cv::Vec3i &clr = cv::Vec3i(255, 255, 255)) ;


private:

    boost::shared_ptr<FaceDetectorImpl> pimpl_ ;
    Parameters params_ ;

};

}
}
#endif
