#ifndef __SHAPE_MODEL_H__
#define __SHAPE_MODEL_H__

#include <eigen3/Eigen/Core>
#include <certh_face/AnnotatedDataset.h>
#include <certh_core/PointList2D.h>
#include <certh_core/BinaryStream.h>

using certh_core::PointList2d ;

namespace certh_face {

// Basic point distribution model

class ShapeModel
{
public:

    ShapeModel() {}

    // Train the model using an annotated data set.
    void train(const AnnotatedDataset &ds, unsigned int maxShapeVectors = 20, double energyToRetain = 0.95 ) ;

    // Fit model to points
    void fit(const PointList2d &pts, Eigen::Affine2d &pose, Eigen::VectorXd &b) ;

    // Robust Fit model with regularization constraints. The dist vector contains a measure of uncertainty for each point.
    void fit(const PointList2d &pts, const Eigen::VectorXd &dist, Eigen::Affine2d &pose, Eigen::VectorXd &b) ;

    // make a new shape x based on model parameters v
    void synthesize(const Eigen::VectorXd &v, PointList2d &x) ;

    // find model parameters given shape
    void project(const PointList2d &x, Eigen::VectorXd &v) ;

    // estimate parameters using wighted least squares with regularization constraint
    void projectRobust(const PointList2d &pts, const Eigen::VectorXd &dist, Eigen::VectorXd &v);

    // restrict model to tangent space
    void restrictShape(Eigen::VectorXd &c) ;

    void read(certh_core::BinaryStream &strm) ;
    void write(certh_core::BinaryStream &strm) ;

    unsigned int dimension() const { return LS_.rows() ; }

    static PointList2d mean(const std::vector<PointList2d> &shapes) ;
    static double procrustes(std::vector<PointList2d> &shapes, PointList2d &mean_shape, bool tangent = true) ;
    static double centerAndScale(PointList2d &shape);
    static double align(PointList2d &shape, const PointList2d &meanShape) ;

private:
    Eigen::MatrixXd US_ ; // Shape eigen-vectors
    Eigen::VectorXd MS_ ; // Mean-shape
    Eigen::VectorXd LS_ ; // Shape eigen-values

} ;

}



#endif
