#ifndef FACEDETECTION_H
#define FACEDETECTION_H

#include <certh_face/vj/FaceDetector.h>
#include <certh_face/rf/LandmarkDetector.h>

#include <certh_face/dlib/FaceDetector.h>
#include <certh_face/dlib/LandmarkDetector.h>
#include <certh_face/IdentityClassifier.h>
#include <certh_face/openface/FaceDescriptor.h>
#include <certh_face/FacialExpressionClassifier.h>

#include <opencv2/highgui/highgui.hpp>
#include <boost/filesystem.hpp>
#include <boost/algorithm/string.hpp>
#include <ros/package.h>

#include <certh_core/gfx.h>

class FaceDetection_upper
{
public:
  FaceDetection_upper();
  void Init(bool use_cuda, std::string fe_expressions) ;
  cv::Mat Detect(cv::Mat frame, bool det_id, bool det_emo) ;
  cv::Mat DetectFace(cv::Mat frame, bool det_id) ;
  void Show(cv::Mat &frame) ;
  std::string person_id;
  std::string emotion;
  bool detected;

private:
  void rpyFromMat(const Eigen::Matrix3d &r, double &roll, double &pitch, double &yaw) ;
  void drawLandmarks(const certh_core::PointList2d &pts, certh_core::gfx::Context &ctx) ;



  std::string data_path, classifier_path, out_path, expressions ;
  float score_threshold;

  certh_face::dlib::FaceDetector dlib_fd ;
  certh_face::dlib::FaceDetector::Parameters dlib_fd_params ;
  certh_face::dlib::FacialLandmarkDetector dlib_det ;

  certh_face::openface::DescriptorExtractor desc_ex ;
  certh_face::IdentityClassifier icls ;
  certh_face::FacialExpressionClassifier ecls ;

  std::vector<std::string> fe_tokens ;
};

#endif // FACEDETECTION_H
