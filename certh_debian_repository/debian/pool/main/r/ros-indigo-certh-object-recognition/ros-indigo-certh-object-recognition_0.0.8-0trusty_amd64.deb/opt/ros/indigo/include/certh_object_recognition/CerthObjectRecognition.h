#ifndef CERTHOBJECTRECOGNITION_H
#define CERTHOBJECTRECOGNITION_H

#include <iostream>
#include <certh_object_recognition/HFTest.h>
#include <certh_object_recognition/PillBoxDetector.h>
#include <certh_core/RGBDUtil.h>
#include <certh_core/Calibration.h>

#include <pcl/point_cloud.h>
#include <pcl/visualization/pcl_visualizer.h>
#include <pcl/sample_consensus/method_types.h>
#include <pcl/sample_consensus/model_types.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/project_inliers.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/kdtree.h>
#include <pcl/features/normal_3d_omp.h>
#include <pcl/surface/poisson.h>
#include <pcl/registration/icp.h>
#include <pcl/surface/concave_hull.h>
#include <pcl/filters/passthrough.h>
#include <pcl/io/pcd_io.h>
#include <pcl/filters/crop_hull.h>

class CerthObjectRecognition
{
    std::string forest_ ;
    std::string caffe_definition_ ;
    std::string caffe_weights_ ;
    std::string meshes_ ;
    int stride_ ;
    std::string str_use_gpu_ ;
    bool use_gpu_ ;
    int threads_ ;
    double max_depth_range_in_m_ ;

    float z_min_ ;
    float z_max_ ;
    float y_min_ ;
    float y_max_ ;
    float x_min_;
    float x_max_;

    float min_dist_;
    float max_dist_;

    HFTest *hf ;

public:

    struct DetectionResult{
        std::string object_label ;
        Eigen::Matrix4f object_pose ;
        Eigen::Vector4f longer_dimension ;
        std::vector<Eigen::Vector4f> axial_symmetry ;
        Eigen::Vector4f bounding_box ;
        std::vector<cv::Point> bounding_box2D;

        Eigen::Vector4f surface_normal;
        Eigen::Vector4f vectorA;
        Eigen::Vector4f vectorB;
        bool floor;
    };

    CerthObjectRecognition(std::string forest, std::string caffe_definition,
                           std::string caffe_weights, std::string meshes,
                           int stride, std::string str_use_gpu, int threads,
                           double max_depth_range_in_m) ;

    CerthObjectRecognition(std::string forest, std::string caffe_definition,
                           std::string caffe_weights, std::string meshes,
                           int stride, std::string str_use_gpu, int threads,
                           double max_depth_range_in_m,
                           float x_min, float x_max, float y_min, float y_max, float z_min, float z_max,
                           float min_dist, float max_dist) ;

    void setWorkspaceThresholds(float x_min, float x_max,
                                float y_min, float y_max,
                                float z_min, float z_max);

    void detectObjects(cv::Mat &rgb, cv::Mat &depth,
                  double fx, double fy,
                  double cx, double cy,
                  int height, int width,
                  std::vector<std::string> &objects,
                  std::vector<DetectionResult> &detection_result) ;

    void detectObjects(cv::Mat &rgb, cv::Mat &depth,
                  double fx, double fy,
                  double cx, double cy,
                  int height, int width,
                  std::vector<std::string> &objects,
                  std::vector<DetectionResult> &detection_result,
                  Eigen::Vector4d &coeffs,
                  pcl::PointCloud<pcl::PointXYZRGB>::Ptr &supporting_surface,
                  pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull,
                  std::vector<pcl::Vertices> &polygons,
                  std::string mesh_folder,
                  bool not_floor);

    void detectObjects(cv::Mat &rgb, cv::Mat &depth,
                  double fx, double fy,
                  double cx, double cy,
                  int height, int width,
                  std::vector<std::string> &objects,
                  std::vector<DetectionResult> &detection_result,
                  Eigen::Vector4d &coeffs,
                  pcl::PointCloud<pcl::PointXYZRGB>::Ptr &supporting_surface,
                  pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull,
                  std::vector<pcl::Vertices> &polygons,
                  std::string mesh_folder,
                  bool not_floor,
                  Eigen::Affine3d tf,
                  int parent_id);

    void segmentDominantPlane(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                              cv::Mat &mask, Eigen::Vector4d &coeffs,
                              pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull);

    void segmentSupportingSurface(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                              cv::Mat &mask, Eigen::Vector4d &coeffs,
                              pcl::PointCloud<pcl::PointXYZRGB>::Ptr &supporting_surface,
                              pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull,
                              std::vector<pcl::Vertices> &polygons);

    int segmentSupportingSurface(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,
                              cv::Mat &mask, Eigen::Vector4d &coeffs,
                              pcl::PointCloud<pcl::PointXYZRGB>::Ptr &supporting_surface,
                              pcl::PointCloud<pcl::PointXYZRGB>::Ptr &convex_hull,
                              std::vector<pcl::Vertices> &polygons,
                              Eigen::Affine3d &tf);

    void projectPointToPlane(const pcl::PointXYZ &initial_p, const Eigen::Vector4d &coeffs, pcl::PointXYZ &projected_p);

    void projectPointToPlane(const pcl::PointXYZRGB &initial_p, const Eigen::Vector4d &coeffs, pcl::PointXYZRGB &projected_p);

    double pointToLineDistance(const pcl::PointXYZRGB &initial_p, const pcl::PointXYZRGB &pointA, const pcl::PointXYZRGB &pointB,
                               pcl::PointXYZRGB &pointT);

    void getBoundingBox(PillBoxDetector::BoundingBox &bb,
                        Eigen::Matrix4f &pose,
                        std::vector<cv::Point> &bb2D, Eigen::Vector4f &bb3D,
                        Eigen::Vector4f &longer_axis, float fx_, float fy_, int cx_, int cy_);

    void world_to_image_coords(float x, float y, float z, int &row, int &col, float fx_, float fy_, int cx_, int cy_);

};


#endif // CERTHOBJECTRECOGNITION_H
