#ifndef	__RECTANGLE_2D_H
#define	__RECTANGLE_2D_H

#include <certh_core/config.h>
#include <certh_core/Point2D.h>

#include <math.h>

namespace certh_core {

class Rectangle2d
{
protected:

    Point2d tl;		// top left corner (origin)
    Point2d br;		// bottom right corner (corner)

 public:

    Rectangle2d(double left=0, double top=0, double width=0, double height=0);
    Rectangle2d(const Point2d&, const Point2d&);
    Rectangle2d(const Rectangle2d&);

    Point2d origin() const	{ return tl; }
    Point2d corner() const	{ return br; }
    Point2d topLeft() const	{ return tl; }
    Point2d topCenter() const	{ return Point2d((br.x()+tl.x())/2,tl.y()); }
    Point2d topRight() const	{ return Point2d(br.x(),tl.y()); }
    Point2d rightCenter() const	{ return Point2d(br.x(),(br.y()+tl.y())/2); }
    Point2d bottomRight() const	{ return br; }
    Point2d bottomCenter() const	{ return Point2d((br.x()+tl.x())/2,br.y()); }
    Point2d bottomLeft() const	{ return Point2d(tl.x(),br.y()); }
    Point2d leftCenter() const	{ return Point2d(tl.x(),(br.y()+tl.y())/2); }
    Point2d center() const	{ return Point2d((br.x()+tl.x())/2,(br.y()+tl.y())/2); }
    Point2d extent() const	{ return Point2d(br.x()-tl.x(),br.y()-tl.y()); }
    double area() const		{ return width()*height(); }
    double width() const		{ return br.x()-tl.x() ; }
    double height() const		{ return br.y()-tl.y() ; }

    Rectangle2d operator&&(const Rectangle2d&) const;	// intersection
    Rectangle2d operator||(const Rectangle2d&) const;	// union

    void operator+=(const Point2d&);			// translate
    void operator-=(const Point2d&);

    bool contains(const Point2d &) const;
    bool contains(const Rectangle2d &) const;

    bool intersects(const Rectangle2d &) const;

    void moveTo(const Point2d &);

    friend std::ostream & operator << (std::ostream &strm, const Rectangle2d &r) ;
};

inline Rectangle2d::Rectangle2d(double left, double top, double width, double height)
{
    tl = Point2d(left, top);
    br = Point2d(left + width, top + height);
}

inline Rectangle2d::Rectangle2d(const Point2d& o, const Point2d& c)
{
    tl = o;
    br = c;
}

inline Rectangle2d::Rectangle2d(const Rectangle2d& r) : tl(r.tl), br(r.br) {}

inline Rectangle2d Rectangle2d::operator&&(const Rectangle2d& r) const
{
    return Rectangle2d(Point2d(std::max(tl.x(), r.tl.x()), std::max(tl.y(), r.tl.y())),
        Point2d(std::min(br.x(), r.br.x()), std::min(br.y(), r.br.y()))) ;
}


inline Rectangle2d Rectangle2d::operator||(const Rectangle2d& r) const
{
    return Rectangle2d(Point2d(std::min(tl.x(), r.tl.x()), std::min(tl.y(), r.tl.y())),
        Point2d(std::max(br.x(), r.br.x()), std::max(br.y(), r.br.y()))) ;
}

inline void Rectangle2d::operator+=(const Point2d& p)
{
    tl += p;
    br += p;
}

inline void Rectangle2d::operator-=(const Point2d& p)
{
    tl -= p;
    br -= p;
}

inline bool Rectangle2d::contains(const Point2d& p) const
{
    return (tl.x() <= p.x() && tl.y() <= p.y() ) && (p.x() <= br.x() && p.y() <= br.y());
}

inline bool Rectangle2d::contains(const Rectangle2d& r) const
{
    return ( contains(r.tl) && contains(r.br) );
}

inline bool Rectangle2d::intersects(const Rectangle2d& r) const
{
    if ( std::max(tl.x(), r.tl.x()) < std::min(br.x(), r.br.x()) &&
        std::max(tl.y(), r.tl.y()) < std::min(br.y(), r.br.y()) ) return true ;
    return false;
}

inline void Rectangle2d::moveTo(const Point2d& p)
{
    br += p-tl;
    tl = p;
}

inline std::ostream & operator << (std::ostream &strm, const Rectangle2d &r)
{
    return strm << "{ " << r.topLeft() << " " << r.bottomRight() << " }" ;
}
/////////////////////////////////////


} // namespace cpm

#endif
