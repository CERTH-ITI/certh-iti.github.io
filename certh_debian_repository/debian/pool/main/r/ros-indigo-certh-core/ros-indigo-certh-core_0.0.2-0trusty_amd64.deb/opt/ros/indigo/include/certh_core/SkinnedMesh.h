#ifndef __SKINNED_MESH_H__
#define __SKINNED_MESH_H__

#include <certh_core/Skeleton.h>
#include <certh_core/Pose.h>


namespace certh_core {
// A generic skinned mesh

class SkinnedMesh {
public:

    SkinnedMesh()
    {
        bone2sdfpart_[0]=8; //chest
        bone2sdfpart_[1]=8; //chest
        bone2sdfpart_[2]=8; //chest
        //bone2sdfpart_[16]=8; //chest
        bone2sdfpart_[16]=9;
        bone2sdfpart_[21]=8; //chest

        bone2sdfpart_[5]=3; //handL
        bone2sdfpart_[7]=3; //handL
        bone2sdfpart_[13]=3; //handL
        bone2sdfpart_[24]=3; //handL
        bone2sdfpart_[26]=3; //handL

        bone2sdfpart_[6]=2; //handR
        bone2sdfpart_[8]=2; //handR
        bone2sdfpart_[14]=2; //handR
        bone2sdfpart_[25]=2; //handR
        bone2sdfpart_[27]=2; //handR

        bone2sdfpart_[9]=13; //footL
        bone2sdfpart_[28]=13; //footL

        bone2sdfpart_[10]=14; //footR
        bone2sdfpart_[29]=14; //footR


        bone2sdfpart_[11]=4; //forearmL
        bone2sdfpart_[12]=5; //forearmR

        bone2sdfpart_[3]=6;
        bone2sdfpart_[4]=6;
        bone2sdfpart_[15]=6; //head
        bone2sdfpart_[17]=6; //head

        bone2sdfpart_[18]=7; //neck

        bone2sdfpart_[19]=11; //shinL

        bone2sdfpart_[20]=12; //shinR

        bone2sdfpart_[22]=9; //thighL

        bone2sdfpart_[23]=10; //thighR

        bone2sdfpart_[30]=0; //upperARML

        bone2sdfpart_[31]=1; //upperARMR
    }

    // apply the given bone transformations to the mesh and return new vertices and normals.

    void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const;

    void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm, Eigen::Vector3f& bboxMin, Eigen::Vector3f& bboxMax) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices, std::vector<Eigen::Vector3f> &mpos,Eigen::Vector3f& bboxMin, Eigen::Vector3f& bboxMax) const;

    void getTransformedVertices(const Pose &p, std::vector<Eigen::Vector3f> &mpos) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices,
                                std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const ;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices, std::vector<Eigen::Vector3f> &mpos) const;

    void getTransformedVertices(const Pose &p, const std::vector<uint32_t> indices, const std::vector <float>& visibility, std::vector<Eigen::Vector3f> &mpos) const;


    void getTransformedVerticesPartial(const Pose &p, const std::vector<std::string> &bones, std::vector<Eigen::Vector3f> &mpos, std::vector<Eigen::Vector3f> &mnorm) const ;

    void makeColorMap(std::vector<cv::Vec3b> &clrs) ;

    uint getDominantBone(const uint vtx_idx) const ;

    void computeWeights() ;

public:

#define MAX_BONES_PER_VERTEX 4

    struct VertexBoneData
    {
        int id_[MAX_BONES_PER_VERTEX];
        float weight_[MAX_BONES_PER_VERTEX];

        VertexBoneData() ;

        void reset() ;
        void addBoneData(uint boneID, float w) ;
        void normalize() ;
    };

    // flat version of mesh data (e.g. to be used for rendering)

    std::vector<Eigen::Vector3f> positions_ ;
    std::vector<Eigen::Vector3f> normals_ ;
    std::vector<Eigen::Vector2f> tex_coords_ ;
    std::vector<VertexBoneData> bones_ ;
    std::vector<uint> indices_ ;
    std::vector<double> weights_ ;

    Skeleton skeleton_ ;

    std::map <int,int> bone2sdfpart_;

};

} // namespace certh_core

#endif
