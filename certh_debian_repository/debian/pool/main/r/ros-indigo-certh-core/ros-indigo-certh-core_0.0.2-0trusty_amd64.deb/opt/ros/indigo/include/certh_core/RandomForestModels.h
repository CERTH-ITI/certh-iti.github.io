#ifndef __RANDOM_FOREST_MODELS_H__
#define __RANDOM_FOREST_MODELS_H__

#include <certh_core/BinaryStream.h>
#include <certh_core/DataSet.h>

#include <boost/random.hpp>
#include <vector>

// The following are interfaces of classes that have to be implemented to concrete objects by the random forest algorithms

namespace certh_core {

// An abstract weak learner parametrized by dataset type
template<class S>
class IWeakLearner
{
public:
    typedef IDataSet<S> dataset_t ;

    // decide true/false based on threshold
    virtual bool decide(const dataset_t &data, unsigned int idx) const = 0;

    // also the derived class should define a serialization implementation

    virtual void read(BinaryStream &) = 0;
    virtual void write(BinaryStream &) = 0 ;
};

// This should be overrided to provide a randomly selected feature. Parametrized by a learner type
// The sample is called many times to generate random features (weak learners)
/*
template<class L, class R>
class IWeakLernerSampler
{
public:

    typedef L learner_t ;
    typedef typename L::dataset_t dataset_t ;

    IWeakLernerSampler(const dataset_t &ds, std::vector<unsigned int> &subset, unsigned int bidx, unsigned int eidx) ;

    virtual learner_t sample(R &g) = 0 ;
};
*/
// a prediction model that aggregates statistics at RF nodes, Parameterized by Prediction model type T and dataset type S
template<class T, typename S>
class IPredictionModel {
public:

    typedef S dataset_t ;

    // add feature to model
    virtual void aggregate(const dataset_t &data, unsigned int idx) = 0;

    // agregate data from other model
    virtual void aggregate(const T &other) = 0;

    // compute the information gain of replacing this model with the partioned models (e.g. left, right nodes)
    virtual double gain(const T &leftChild, const T& rightChild) = 0;

    // serialization
    virtual void read(BinaryStream &) = 0;
    virtual void write(BinaryStream &) = 0;
};


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

// Sample a random axis and threshold

template<typename D>
class AxisSplitLearner: public IWeakLearner<D>
{
public:
    typedef IWeakLearner<D> learner_t ;
    typedef typename learner_t::dataset_t dataset_t ;

    AxisSplitLearner() {}
    AxisSplitLearner(uint32_t axis, double threshold): axis_(axis), threshold_(threshold) {}

    // decide true/false based on threshold
    bool decide(const dataset_t &ds, unsigned int idx) const {
        return ds.getSampleCoordinate(idx, axis_) < threshold_ ;
    }

    // also the derived class should define a serialization implementation

    virtual void read(BinaryStream &strm) {
        strm.read(axis_) ;
        strm.read(threshold_) ;
    }

    virtual void write(BinaryStream &strm) {
        strm.write(axis_) ;
        strm.write(threshold_) ;
    }

private:

    uint32_t axis_;
    double threshold_ ;
};

/*
template <class D>
class AxisAlignedSampler: public IWeakLernerSampler<AxisSplitLearner<D> >
{
public:
    typedef D dataset_t ;
    typedef typename dataset_t::coord_t coord_t ;
    typedef AxisSplitLearner<D> learner_t ;

   AxisAlignedSampler(const dataset_t &ds, std::vector<unsigned int> &subset, unsigned int bidx, unsigned int eidx) {
        dim_ = ds.getDimension() ;

        rangeMin.resize(dim_) ;
        rangeMax.resize(dim_) ;

        for( int i=0 ; i<dim_ ; i++ )
        {
            coord_t minV = std::numeric_limits<coord_t>::max() ;
            coord_t maxV = std::numeric_limits<coord_t>::min() ;

            for(int j = bidx ; j<eidx ; j++ )
            {
                unsigned int idx = subset[j] ;
                minV = std::min(minV, ds.getSampleCoordinate(idx, i)) ;
                maxV = std::max(maxV, ds.getSampleCoordinate(idx, i)) ;
            }

            rangeMin[i] = minV ;
            rangeMax[i] = maxV ;
        }

    }

    learner_t sample(RNG &rng) {

        boost::random::uniform_int_distribution<> dist(0, dim_-1) ;
        uint32_t axis  = dist(rng) ;
        boost::random::uniform_real_distribution<> rdist(rangeMin[axis], rangeMax[axis]) ;
        double threshold = rdist(rng) ;

        return learner_t(axis, threshold) ;
    }


    std::vector<coord_t> rangeMin, rangeMax ;
    typename dataset_t::dimension_t dim_ ;

} ;
*/
// linear combination of two first coordinates thresholded

template<class D>
class Linear2DLearner
{
public:
    typedef IDataSet<D> dataset_t ;
    typedef typename dataset_t::coord_t coord_t ;

    Linear2DLearner() {}
    Linear2DLearner(double dx, double dy): dx_(dx), dy_(dy) {}

    // decide true/false based on threshold
    double response(const dataset_t &ds, unsigned int idx) const {

        coord_t cx = ds.getSampleCoordinate(idx, 0) ;
        coord_t cy = ds.getSampleCoordinate(idx, 1) ;

        return dx_ * cx + dy_ * cy  ;
    }

    template <class R>
    void sample(const dataset_t &ds, R &rng_)
    {
        boost::random::uniform_real_distribution<> cdist(-1, 1) ;

        dx_ = cdist(rng_) ;
        dy_ = cdist(rng_) ;
        double len = sqrt(dx_*dx_ + dy_*dy_) ;

        dx_ /= len ;
        dy_ /= len ;
    }

    friend std::ostream &operator << (std::ostream &strm, const Linear2DLearner<D> &l)
    {
        strm << l.dx_ << ' ' << l.dy_  ;
        return strm ;
    }

    virtual void read(BinaryStream &strm) {
        strm.read(dx_) ;
        strm.read(dy_) ;
    }
    virtual void write(BinaryStream &strm) {
        strm.write(dx_) ;
        strm.write(dy_) ;
    }

private:

    double dx_, dy_ ;
};

/*
template <class D>
class LinearSampler
{
public:
    typedef IDataSet<D> dataset_t ;
    typedef typename dataset_t::coord_t coord_t ;
    typedef Linear2DLearner<D> learner_t ;
    typedef D storage_t ;
    typedef typename dataset_t::sample_idx_t sample_idx_t ;

    LinearSampler(const dataset_t &ds, RNG &rng, uint8_t depth, std::vector<sample_idx_t> &subset, unsigned int bidx, unsigned int eidx): rng_(rng) {
        dim_ = ds.getDimension() ;

        rangeMin.resize(dim_) ;
        rangeMax.resize(dim_) ;

        for( int i=0 ; i<dim_ ; i++ )
        {
            coord_t minV = std::numeric_limits<coord_t>::max() ;
            coord_t maxV = std::numeric_limits<coord_t>::min() ;

            for(int j = bidx ; j<eidx ; j++ )
            {
                unsigned int idx = subset[j] ;
                minV = std::min(minV, ds.getSampleCoordinate(idx, i)) ;
                maxV = std::max(maxV, ds.getSampleCoordinate(idx, i)) ;
            }

            rangeMin[i] = minV ;
            rangeMax[i] = maxV ;
        }

    }

    learner_t sample() {
        boost::random::uniform_int_distribution<> dist(0, dim_-1) ;
        boost::random::uniform_real_distribution<> cdist(-1, 1) ;

        double dx = cdist(rng_), dy = cdist(rng_) ;
        double len = sqrt(dx*dx + dy*dy) ;

        dx /= len ;
        dy /= len ;

        double s1 = -rangeMin[0] - rangeMin[1] ;
        double s2 = rangeMax[0] + rangeMax[1] ;

        boost::random::uniform_real_distribution<> rdist(s1, s2) ;
        double threshold = rdist(rng_) ;

        return learner_t(dx, dy, threshold) ;
    }


    std::vector<coord_t> rangeMin, rangeMax ;
    typename dataset_t::dimension_t dim_ ;
    RNG &rng_ ;

} ;
*/

// Histogram statistics widely used for classification forests

template <typename D>
class HistogramModel: public IPredictionModel<HistogramModel<D>, IDataSet<D> >
{
public:
    typedef IDataSet<D> dataset_t ;
    typedef typename dataset_t::coord_t storage_t ;


    HistogramModel(): bins_(0), count_(0), samples_(0) {}
    ~HistogramModel() {
        if ( bins_ ) delete [] bins_ ;
    }

    HistogramModel &operator = (const HistogramModel &other) {
        allocate(other.count_, false) ;
        samples_ = other.samples_ ;
        memcpy(bins_, other.bins_, 8*count_) ;
		return *this ;
    }

    // add feature to model
    void aggregate(const dataset_t &data, unsigned int idx) {
        if ( !bins_ ) allocate(data.getNumLabels(), true) ;

        int lab_idx = data.getSampleLabel(idx) ;

        bins_[lab_idx] ++ ;
        samples_ ++ ;

    }

    uint64_t sampleCount() const { return samples_ ; }

    // agregate data from other model
    void aggregate(const HistogramModel &other) {

        if ( !bins_ ) allocate(other.count_, true) ;

        for(int i=0 ; i<other.count_ ; i++)
            bins_[i] += other.bins_[i] ;

        samples_ += other.samples_ ;
    }

    // bin with the highest score

    uint32_t highest() const {

        uint64_t max_count = 0 ;
        uint32_t best = -1 ;

        for( int i=0 ; i<count_ ; i++ )
        {
            if ( bins_[i] > max_count )
            {
                max_count = bins_[i] ;
                best = i ;
            }
        }

        return best ;
    }

    // compute the information gain of replacing this model with the partioned models (e.g. left, right nodes)

    double gain(const HistogramModel &leftChild, const HistogramModel& rightChild) {
        double entropyBefore = entropy();

        const uint64_t n1 = leftChild.sampleCount() ;
        const uint64_t n2 = rightChild.sampleCount() ;

        uint64_t totalSamples = n1 + n2;

        if ( totalSamples <= 1 ) return 0 ;

        double entropyAfter = (n1 * leftChild.entropy() + n2 * rightChild.entropy())/totalSamples ;

        return entropyBefore - entropyAfter;
    }


    void read(BinaryStream &strm) {
        strm.read(count_) ;
        strm.read(samples_) ;
        allocate(count_, false) ;
        strm.read(bins_, count_) ;
    }

    void write(BinaryStream &strm) {
        strm.write(count_) ;
        strm.write(samples_) ;
        strm.write(bins_, count_) ;
    }

    friend std::ostream &operator << (std::ostream &strm, const HistogramModel<D> &m)
    {
        strm << m.samples_ << ": " ;
        for(int i=0 ; i<m.count_ ; i++)
            strm << m.bins_[i] << ' ' ;
        return strm ;
    }

private:

    void allocate(size_t count, bool rv = true) {
        if ( bins_ != 0 ) delete [] bins_ ;
        bins_ = new uint64_t [count] ;
        count_ = count ;

        if ( rv )
            memset(bins_, 0, 8*count_) ;
    }

    double entropy() const {
        double result = 0.0 ;

        for (int i = 0; i < count_ ; i++ )
        {
            double p = (double)bins_[i] / (double)samples_;
            result -= p == 0.0 ? 0.0 : p * log(p)/log(2.0);
        }

        return result;
    }

    uint64_t *bins_;
    uint32_t count_; // number of bins
    uint64_t samples_; // number of total samples accumulated in histogram

};

} // namespace certh_core


#endif
