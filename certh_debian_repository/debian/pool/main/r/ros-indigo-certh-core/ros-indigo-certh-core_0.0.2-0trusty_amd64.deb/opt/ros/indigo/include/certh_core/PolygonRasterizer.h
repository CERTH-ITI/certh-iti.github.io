#ifndef __POLYGON_SCANNER_H
#define __POLYGON_SCANNER_H

  
class PolygonScanner
{
  PolygonScanner(Point2D *plist, int npts, int nfields = 0) ;

  


}




#endif
