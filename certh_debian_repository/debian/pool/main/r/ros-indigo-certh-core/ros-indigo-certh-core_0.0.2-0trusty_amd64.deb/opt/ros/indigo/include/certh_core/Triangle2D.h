#ifndef __TRIANGLE_2D_H
#define __TRIANGLE_2D_H

#include <certh_core/config.h>
#include <certh_core/Point2D.h>
#include <certh_core/Rectangle2D.h>

namespace certh_core {

class Triangle2d
{
public:

    Triangle2d() {}
    Triangle2d(const Point2d &A, const Point2d &B, const Point2d &C):
        p1(A), p2(B), p3(C) {}
    Triangle2d(const Triangle2d &other):
        p1(other.p1), p2(other.p2), p3(other.p3) {}
    Triangle2d(const Point2d pl[3]):
        p1(pl[0]), p2(pl[1]), p3(pl[2]) {}

    float area() const ;
    Rectangle2d boundingBox() const ;

    bool contains(const Point2d &p) const ;
    bool contains(double x, double y) const { return contains(Point2d(x,y)) ; }

    friend std::ostream &operator << (std::ostream &strm, const Triangle2d &p) ;

    enum ICode { PtInTriangle=1, PtOnEdge=0, PtOnVertex=-1, PtOutTriangle=-2 } ;

    ICode whereIs(const Point2d &p) const ;

    void getBarycentric(double x, double y, double &g0, double &g1, double &g2) const ;

    Point2d p1, p2, p3 ;

    static int orientation(const Point2d &A, const Point2d &B, const Point2d &C) ;
} ;




}

#endif
