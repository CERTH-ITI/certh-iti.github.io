#ifndef _M_FUNCTIONS_H_
#define _M_FUNCTIONS_H_

#include <certh_core/config.h>
#include <eigen3/Eigen/Core>
#include <opencv2/opencv.hpp>

namespace certh_core {

double sum(const Eigen::VectorXd &x) ;
Eigen::VectorXd sum(const Eigen::MatrixXd &x, bool col) ;
float sum(const Eigen::VectorXf &x) ;
Eigen::VectorXf sum(const Eigen::MatrixXf &x, bool col) ;

// mean values
double mean(const Eigen::VectorXd &a) ;
Eigen::VectorXd mean(const Eigen::MatrixXd &a, bool col = true) ;
float mean(const Eigen::VectorXf &a) ;
Eigen::VectorXf mean(const Eigen::MatrixXf &a, bool col = true) ;

// eigne decomposition of self adjoint matrices
void eig(const Eigen::MatrixXd &A, Eigen::VectorXd &L) ;
void eig(const Eigen::MatrixXd &A, Eigen::VectorXd &L, Eigen::MatrixXd &U) ;
void eig(const Eigen::MatrixXf &A, Eigen::VectorXf &L) ;
void eig(const Eigen::MatrixXf &A, Eigen::VectorXf &L, Eigen::MatrixXf &U) ;

// load a matrix from a mat file
// supports MAT file format v5.0
bool load(Eigen::MatrixXd &A, const std::string &fname, const std::string &varname) ;
bool load(Eigen::MatrixXf &A, const std::string &fname, const std::string &varname) ;

// save a matrix to mat file
bool save(const Eigen::MatrixXd &A, const std::string &fname, const std::string &varname, bool append = false, bool compress = false) ;
bool save(const Eigen::MatrixXf &A, const std::string &fname, const std::string &varname, bool append = false, bool compress = false) ;

} // namespace certh_core



#endif
