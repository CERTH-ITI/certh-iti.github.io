#ifndef __POSE_H__
#define __POSE_H__

#include <string>
#include <map>
#include <vector>
#include <Eigen/Geometry>

#include <certh_core/Skeleton.h>
#include <certh_core/BinaryStream.h>

// contains relative transformation of named bones

namespace certh_core {

class Pose {
public:
    Pose() {
        global_trans_ = Eigen::Matrix4f::Identity() ;
        global_scale_ = 1.0 ;
    }

    void setBoneTransform(const std::string &name, const Eigen::Matrix4f &t) ;
    void setBoneTransform(const std::string &name, const Eigen::Quaterniond &t) ;
    bool getBoneTransform(const std::string &name, Eigen::Matrix4f &t) const ;

    void setGlobalTransform(const Eigen::Matrix4f &g) {
        global_trans_ = g ;
    }

    void setGlobalScale(const float &s) {
        global_scale_ = s ;
    }

    Eigen::Matrix4f getGlobalTransform() const { return global_trans_ ; }
    Eigen::Matrix4f getGlobalScaledTransform() const ;
    float getGlobalScale() const { return global_scale_ ; }

    bool loadFromMHP(const std::string &fname) ;
    bool loadFromMHP(const std::string &fname, const std::map<std::string, std::string> &bmap) ;

    friend BinaryStream &operator << (BinaryStream &ar, const Pose &p) {
        ar << p.channels_ << p.global_trans_ << p.global_scale_ ;
        return ar ;
    }
    friend BinaryStream &operator >> (BinaryStream &ar, Pose &p) {
        ar >> p.channels_ >> p.global_trans_ >> p.global_scale_ ;
        return ar ;
    }

    void reset();

private:
    std::map<std::string, Eigen::Matrix4f> channels_ ;
    Eigen::Matrix4f global_trans_ ;
    float global_scale_ ;
};


}

#endif
