#ifndef _HELPERS_H_
#define _HELPERS_H_

#include <certh_core/config.h>

#include <boost/filesystem.hpp>

#include <vector>
#include <string>


namespace certh_core {

// File system

// Find all files/dirs matching a filter
// e.g. similar to php Glob function glob("my/*/dir/*.php", files);
// pattern can contain *, ? and character ranges [], [^] as well as %0xd symbols.
// Notice that are ambiguities when backslashes are used (e.g \*) between folder separators
// and glob escapes. Also two question marks followd by slash is a trigraph and therefore should be prefixed by backslash

std::vector<std::string> glob(const std::string &pattern) ;

// tests if filename matches the filter. The filter is a sequence of glob patterns separated by semicolon

bool pathMatchesFilter(const boost::filesystem::path &pathName, const std::string &filter) ;

// get all subdirs that match the filter (sequence of glob patterns)

std::vector<std::string> subDirs(const boost::filesystem::path &dirName, const std::string &filter) ;

// get all files int the directory that match the filter (sequence of glob patterns)

std::vector<std::string> pathEntries(const boost::filesystem::path &dirName, const std::string &filter) ;

// Get temporary file path located at the specified directory. If dirName is NULL the system temp
// path is used. It does not actually create the file, so it must be used immediately

boost::filesystem::path getTemporaryPath(const std::string &dirName = std::string(), const std::string &prefix = std::string(), const std::string &ext = std::string()) ;


} // namespace cpm
#endif
