#ifndef __KDTREE_H__
#define __KDTREE_H__

#include <vector>
#include <Eigen/Core>

#include <boost/shared_ptr.hpp>

// 3D Point Cloud Search (wrapper over nanoflann)


namespace certh_core {

class KDTreeIndex ;

class KDTree3
{
public:

    KDTree3() {}
    KDTree3(const std::vector<Eigen::Vector3f> &data) ;

    void train(const std::vector<Eigen::Vector3f> &data) ;

    // nearest point
    int nearest(const Eigen::Vector3f &q) ;
    int nearest(const Eigen::Vector3f &q, float &dist) ;

    void knearest(const Eigen::Vector3f &q, uint k, std::vector<uint> &indexes) ;
    void knearest(const Eigen::Vector3f &q, uint k, std::vector<uint> &indexes, std::vector<float> &distances) ;

    void withinRadius(const Eigen::Vector3f &q, float radius, std::vector<uint> &indexes) ;
    void withinRadius(const Eigen::Vector3f &q, float radius, std::vector<uint> &indexes, std::vector<float> &distances) ;

private:

    boost::shared_ptr<KDTreeIndex> index_ ;
} ;

}


#endif
