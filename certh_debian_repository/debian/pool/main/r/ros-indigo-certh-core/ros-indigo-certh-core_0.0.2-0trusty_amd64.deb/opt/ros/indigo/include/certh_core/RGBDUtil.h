#ifndef __RGBD_UTIL_H__
#define __RGBD_UTIL_H__

#include <opencv2/opencv.hpp>

#include <certh_core/Calibration.h>

#include <pcl/point_cloud.h>
#include <pcl/point_types.h>

namespace certh_core {

// Safely samples depth map to obtain depth value at (x, y) and a region of size [-ws, ws] around it.
// If none valid value found returns false.
bool sampleNearestNonZeroDepth(const cv::Mat &dim, int x, int y, ushort &z, int ws=1) ;

// same as above but also performs bilinear interpolation
bool sampleBilinearDepth(const cv::Mat &dim, float x, float y, float &z,int ws=1) ;

// create point cloud from depth image
void depthToPointCloud(const cv::Mat &depth, const PinholeCamera &model_, pcl::PointCloud<pcl::PointXYZ> &cloud) ;

void depthToPointCloud(const cv::Mat &rgb, const cv::Mat &depth, const PinholeCamera &model_, pcl::PointCloud<pcl::PointXYZRGB> &cloud) ;

void depthToPointCloud(const cv::Mat &depth, const PinholeCamera &model_, std::vector<Eigen::Vector3f> &coords, uint sampling = 1) ;

}

#endif
