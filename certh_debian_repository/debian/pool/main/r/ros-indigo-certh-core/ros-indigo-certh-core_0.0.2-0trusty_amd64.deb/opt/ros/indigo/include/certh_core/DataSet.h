#ifndef __ML_DATASET_H__
#define __ML_DATASET_H__

#include <certh_core/config.h>

#include <vector>

#include <boost/cstdint.hpp>
#include <boost/random.hpp>
#include <boost/random/random_device.hpp>

#include <string>
#include <eigen3/Eigen/Eigen>

namespace certh_core {

// abstract interface for a generic dataset class parametrized by dataset storage traits object
template<typename S>
class IDataSet
{
public:

    typedef typename S::label_t label_t ;
    typedef typename S::sample_idx_t sample_idx_t ;
    typedef typename S::dimension_t dimension_t ;
    typedef typename S::sample_t sample_t ;
    typedef typename S::coord_t coord_t;
    typedef typename S::storage_t storage_t;

    // Get number of samples available
    virtual uint64_t numSamples() const = 0;

    // Get dimension
    virtual label_t getDimension() const = 0;

    // Return true if the dataset is annotated
    // Each sample is then associated with an integer [0 - nLabels-1]
    virtual bool hasLabels() const = 0 ;

    virtual label_t getNumLabels() const = 0 ;

    // Get list of label names
//    virtual void getLabelNames(std::vector<std::string> &labels) const = 0 ;

    // Get the number of samples that have the given label.
 //   virtual uint64_t getNumSamplesForLabel(label_t idx) const = 0 ;

    // Get the indices of the samples that have the given id.
//    virtual void getSamplesForLabel(label_t label, std::vector<sample_idx_t> &indices) const = 0;

    // Get label associated with the specific sample
    virtual label_t getSampleLabel(sample_idx_t idx) const = 0;

    virtual coord_t getSampleCoordinate(sample_idx_t idx, dimension_t c) const = 0 ;

    virtual sample_t getSample(sample_idx_t idx) const = 0 ;
    virtual void setLabel(sample_idx_t idx, label_t l) = 0 ;

    virtual storage_t getMat() const = 0 ;

    virtual void getSampleLabels(std::vector<label_t> &labels) = 0 ;

    virtual IDataSet<S> &getThis() = 0 ;
} ;

// specialization where samples are stored as rows of a matrix

template<class T>
class MatStorageTraits {
public:
    typedef uint32_t label_t ;
    typedef uint64_t sample_idx_t ;
    typedef uint32_t dimension_t ;
    typedef Eigen::Matrix<T, Eigen::Dynamic, 1> sample_t ;
    typedef Eigen::Matrix<T, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> storage_t ;
    typedef T coord_t ;
};

template<class T>
class DataSetMat: public IDataSet<MatStorageTraits<T> >
{
public:

//    typedef IDataSet<DataSetMatStorage<T> > dataset_t ;
    typedef typename MatStorageTraits<T>::label_t label_t ;
    typedef typename MatStorageTraits<T>::sample_idx_t sample_idx_t ;
    typedef typename MatStorageTraits<T>::dimension_t dimension_t ;
    typedef typename MatStorageTraits<T>::sample_t sample_t ;
    typedef typename MatStorageTraits<T>::coord_t coord_t;
    typedef typename MatStorageTraits<T>::storage_t mat_t ;

    // Get number of samples available
    uint64_t numSamples() const {
        return data_.rows() ;
    }

    // Get dimension
    dimension_t getDimension() const {
        return data_.cols() ;
    }

    // Return true if the dataset is annotated
    // Each sample is then associated with an integer [0 - nLabels-1]
    bool hasLabels() const {
        return !labels_.empty() ;
    }

    // Get list of label names
    void getLabelNames(std::vector<std::string> &labels) const ;

    // Get the number of samples that have the given label.
    uint64_t getNumSamplesForLabel(label_t label) const ;

    // Get the indices of the samples that have the given id.
    void getSamplesForLabel(label_t label, std::vector<sample_idx_t> &indices) const ;

    // Get label associated with the specific sample
    label_t getSampleLabel(sample_idx_t idx) const {
        return data_labels_[idx] ;
    }

    // Get coordinate of a sample
    T getSampleCoordinate(sample_idx_t idx, dimension_t c) const {
        return data_(idx, c) ;
    }

    // Get sample

    sample_t getSample(sample_idx_t idx) const {
        return data_.row(idx) ;
    }

    label_t getNumLabels() const {
        return labels_.size()  ;
    }


    void setLabel(sample_idx_t idx, label_t l)
    {
        data_labels_[idx] = l ;
    }

    mat_t getMat() const { return data_ ; }

    void getSampleLabels(std::vector<label_t> &labels) {
        std::copy(data_labels_.begin(), data_labels_.end(), std::back_inserter(labels)) ;
    }

protected:

    virtual IDataSet<MatStorageTraits<T> > &getThis()  { return *this ; }

    std::vector<label_t> data_labels_ ;
    mat_t data_ ;
    std::vector<std::string> labels_ ;
} ;

typedef DataSetMat<double> DataSetMatd ;
typedef DataSetMat<float> DataSetMatf ;

template<class sample_idx_t>
void sample_with_replacement(uint32_t n, sample_idx_t N, std::vector<sample_idx_t> &subset) {

    namespace rnd = boost::random ;
        // Random generator
    rnd::random_device rdev ;
    rnd::mt19937 rng(rdev);

    sample_idx_t max_idx = static_cast<sample_idx_t>(N-1) ;

    std::vector<sample_idx_t> vidx ;
    for( int i=0 ; i<N ; i++ ) vidx.push_back(i) ;

    for ( int i=0; i<n ; i++ )
    {
        rnd::uniform_int_distribution <> ud(0, max_idx) ;
        int index = ud(rng) ;
        std::swap(vidx[index],vidx[max_idx]);
        subset.push_back(vidx[max_idx]);
        max_idx -- ;
    }

}
// subset of a dataset where calls are delegated to full dataset and only the indexes of the subset are stored

template<class D>
class DataSetSubset: public IDataSet<D>
{
public:
    typedef IDataSet<D> dataset_t ;
    typedef typename D::label_t label_t ;
    typedef typename D::sample_idx_t sample_idx_t ;
    typedef typename D::dimension_t dimension_t ;
    typedef typename D::sample_t sample_t ;
    typedef typename D::coord_t coord_t;
    typedef typename D::storage_t storage_t ;

    DataSetSubset(dataset_t &d): data_(d.getThis()) {}
    DataSetSubset(dataset_t &d, const std::vector<sample_idx_t> &sub): data_(d.getThis()), subset_(sub) {}
    DataSetSubset(dataset_t &d, const std::vector<sample_idx_t> &sub, sample_idx_t b, sample_idx_t e): data_(d.getThis()) {
        std::copy(sub.begin() + b, sub.begin() + e, std::back_inserter(subset_)) ;
    }
    DataSetSubset(dataset_t &d, sample_idx_t b, sample_idx_t e): data_(d.getThis()) {
        for( int i=b ; i<e ; i++ ) subset_.push_back(i) ;
    }

    DataSetSubset(DataSetSubset<D> &d): data_(d.getThis()) {}

    DataSetSubset(DataSetSubset<D> &d, const std::vector<sample_idx_t> &sub): data_(d.getThis()), subset_(sub) {}
    DataSetSubset(DataSetSubset<D> &d, const std::vector<sample_idx_t> &sub, sample_idx_t b, sample_idx_t e): data_(d.getThis()) {
        std::copy(sub.begin() + b, sub.begin() + e, std::back_inserter(subset_)) ;
    }
    DataSetSubset(DataSetSubset<D> &d, sample_idx_t b, sample_idx_t e): data_(d.getThis()) {
        for( int i=b ; i<e ; i++ ) subset_.push_back(i) ;
    }

    // make with n randomly selected points from the original dataset
    void random(sample_idx_t n) ;

    virtual uint64_t numSamples() const {
        return subset_.size() ;
    }

    virtual dimension_t getDimension() const {
        return data_.getDimension() ;
    }

    virtual bool hasLabels() const {
        return !data_.hasLabels() ;
    }

    virtual label_t getSampleLabel(sample_idx_t idx) const {
        sample_idx_t c = subset_[idx]  ;
        return data_.getSampleLabel(c) ;
    }

    virtual coord_t getSampleCoordinate(sample_idx_t idx, dimension_t c) const {
        sample_idx_t oridx = subset_[idx]  ;
        return data_.getSampleCoordinate(oridx, c) ;
    }

    virtual sample_t getSample(sample_idx_t idx) const {
        sample_idx_t c = subset_[idx]  ;
        return data_.getSample(c) ;
    }

    virtual label_t getNumLabels() const {
        return data_.getNumLabels()  ;
    }

    virtual void setLabel(sample_idx_t idx, label_t l)
    {
        sample_idx_t c = subset_[idx]  ;
        data_.setLabel(c, l) ;
    }

    virtual storage_t getMat() const {
        storage_t x(numSamples(), getDimension()) ;

        for(int i=0 ; i<subset_.size() ; i++ )
            x.row( i ) = data_.getSample( subset_[i] ) ;

        return x ;
    }

    virtual void getSampleLabels(std::vector<label_t> &labels) {
        for( int i=0 ; i<subset_.size() ; i++ )
        {
            int idx = subset_[i] ;
            labels.push_back(data_.getSampleLabel(idx)) ;
        }

    }
protected:
    virtual dataset_t &getThis() {
        return data_ ;
    }

private:

    dataset_t &data_ ;
    std::vector<sample_idx_t> subset_ ;

} ;

template<class D>
void DataSetSubset<D>::random(sample_idx_t n) {

    sample_with_replacement(n, data_.numSamples(), subset_) ;

}

} // namespace certh_core
#endif
