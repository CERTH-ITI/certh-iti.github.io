#ifndef __POINT_2D_H
#define __POINT_2D_H

//Used for compatibility with old version

#include <certh_core/config.h>

#include <math.h>
#include <iostream>

#include <opencv2/opencv.hpp>

#include <eigen3/Eigen/Geometry>

namespace certh_core {



class Point2d: public Eigen::Vector2d {
public:
    Point2d(): Eigen::Vector2d(0, 0) {}
    Point2d(double x, double y): Eigen::Vector2d(x, y) {}
    Point2d(const cv::Point2d &p): Eigen::Vector2d(p.x, p.y) {}
    Point2d(const cv::Point &p): Eigen::Vector2d(p.x, p.y) {}

    typedef Eigen::Vector2d Base;

    template<typename OtherDerived>
    Point2d(const Eigen::MatrixBase<OtherDerived>& other)
        : Eigen::Vector2d(other)
    { }

    template<typename OtherDerived>
    Point2d & operator= (const Eigen::MatrixBase <OtherDerived>& other) {
        this->Base::operator=(other);
        return *this;
    }

};

typedef Point2d Vector2d ;

inline Point2d max(const Point2d &a, const Point2d &b)
{
    return Point2d(std::max(a.x(), b.x()), std::max(a.y(), b.y())) ;
}

inline Point2d min(const Point2d &a, const Point2d &b)
{
    return Point2d(std::min(a.x(), b.x()), std::min(a.y(), b.y())) ;
}

inline Point2d max(const Point2d &a, const Point2d &b, const Point2d &c)
{
    return max(a, max(b, c)) ;
}

inline Point2d min(const Point2d &a, const Point2d &b, const Point2d &c)
{
    return min(a, min(b, c)) ;
}

/*
class Point2d: public Vector2
{
public:

    Point2d(): Vector2() {}
    Point2d(const Point2d &p): Vector2(p) {}
    Point2d(const Vector2 &d): Vector2(d) {}
    Point2d(double v[2]): Vector2(v) {}
    Point2d(double x, double y): Vector2(x, y) {}
    Point2d(const Point &q): Vector2((double)q.x, (double)q.y) {}

    Point2d(const cv::Point2d &p): Vector2(p.x, p.y) {}
    Point2d(const cv::Vec2d &p): Vector2(p[0], p[1]) {}

    const Point2d &operator=(const Vector2 &v)  {
        m1 = v.m1 ; m2 = v.m2 ; return *this ;
    }

    operator cv::Point2d () {
        return cv::Point2d(x, y) ;
    }

    operator cv::Vec2d () {
        return cv::Vec2d(x, y) ;
    }
} ;


#undef max
#undef min



class Vec2D: public Vector2
{
public:
    Vec2D(): Vector2() {}
    Vec2D(const Vec2D &p): Vector2(p) {}
    Vec2D(double v[2]): Vector2(v) {}
    Vec2D(double x, double y): Vector2(x, y) {}
    Vec2D(const Point2d &p1, const Point2d &p2): Vector2(p1 - p2) {}
    Vec2D(const Vec &q): Vector2((double)q.x, (double)q.y) {}
    Vec2D(const Point2d &q): Vector2(q) {}

    Vec2D(const cv::Point2d &p): Vector2(p.x, p.y) {}
    Vec2D(const cv::Vec2d &p): Vector2(p[0], p[1]) {}

    const Vec2D &operator=(const Vector2 &v) {
        m1 = v.m1 ; m2 = v.m2 ; return *this ;
    }

    operator cv::Point2d () { return cv::Point2d(x, y) ;  }
    operator cv::Vec2d () { return cv::Vec2d(x, y) ;  }

} ;
*/

} // namespace certh_core

#endif

