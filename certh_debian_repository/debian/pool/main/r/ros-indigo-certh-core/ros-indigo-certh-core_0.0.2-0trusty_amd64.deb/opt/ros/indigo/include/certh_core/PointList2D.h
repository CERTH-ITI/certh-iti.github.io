#ifndef _POINT_LIST_2D_H_
#define _POINT_LIST_2D_H_

#include <certh_core/config.h>
#include <certh_core/Point2D.h>

#include <eigen3/Eigen/Core>

#include <vector>

namespace certh_core {

class PointList2d: public std::vector<Point2d>
{
public:

    PointList2d() {}
    PointList2d(double *x, double *y, int n) ;
    PointList2d(const std::vector<Point2d> &pts): std::vector<Point2d>(pts) {}
    PointList2d(const Eigen::VectorXd &x) ;
    PointList2d(const Eigen::MatrixXd &x) ;

    Point2d center() const ;
    void axes(double &l1, Vector2d &v1, double &l2, Vector2d &v2) const ;

    // Procrustes analysis
    // Find the transform  that aligns this shape with the other one:
    // this' = T(s) * T(theta) * this + T(tx, ty)
    Eigen::Affine2d align(const PointList2d &other) const ;

    void transform(const Eigen::Affine2d &xf) ;
    void bbox(Point2d &ul, Point2d &br) const ;

    double norm() const ;
    void translate(const Point2d &offset) ;
    void scale(double s) ;

    void setVector(const Eigen::VectorXd &data) ;

    Eigen::VectorXd toVector() const ;
    Eigen::MatrixXd toMatrix() const ;
} ;




} // namespace cpm

#endif
