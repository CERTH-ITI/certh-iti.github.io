#ifndef __GEOM_UTIL_H__
#define __GEOM_UTIL_H__

#include <Eigen/Geometry>
#include <vector>

namespace certh_core {

// perform mean-shift clustering of point cloud and return all modes
void mean_shift_all(const std::vector<Eigen::Vector3f> &pts, const std::vector<float> &weights, std::vector<Eigen::Vector3f> &u, std::vector<float> &omega,
                    float sigma, unsigned int maxIter, float seed_perc, uint minSeed) ;

// finds 3D affine transform (transl;ation, rotation and scale) given points correspondences and weights.
// variables src, target are (3, n) matrices

void compute_affine_3d(const Eigen::MatrixXf &src, const Eigen::MatrixXf &target, const Eigen::VectorXf &weights,
                       Eigen::Quaterniond &Q, Eigen::Vector3d &T, double &scale) ;

// compute the lookAt transform
Eigen::Matrix4f lookAt(const Eigen::Vector3f & eye,  const Eigen::Vector3f &center, const Eigen::Vector3f &up) ;


}

#endif
