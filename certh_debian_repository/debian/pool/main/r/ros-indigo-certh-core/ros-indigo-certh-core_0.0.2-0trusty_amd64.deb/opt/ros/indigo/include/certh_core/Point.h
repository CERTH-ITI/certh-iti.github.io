#ifndef __POINT_H
#define __POINT_H

#include <certh_core/config.h>

#include <cassert>
#include <algorithm>

#include <opencv2/opencv.hpp>
#include <iostream>

namespace certh_core {

struct Vec ;

struct Point
{
  Point() ;
  Point(const Point &) ;
  Point(int x, int y) ;
  Point(const cv::Point &p) ;
  Point(const cv::Vec2i &p) ;

  Point & operator +=(const Vec &) ;
  Point & operator -=(const Vec &) ;

  friend std::ostream & operator << (std::ostream &strm, const Point &v) ;

  friend bool operator == (const Point &v1, const Point &v2) ;
  friend bool operator != (const Point &v1, const Point &v2) ;

  operator cv::Point () ;
  operator cv::Vec2i () ;

  int x, y ;
} ;

struct Vec
{
  Vec() ;
  Vec(const Vec &) ;
  Vec(int x, int y) ;
  Vec(const cv::Point &) ;
  Vec(const cv::Vec2i &) ;
  Vec(const Point &p1, const Point &p2) ;

  friend Point operator +(const Point &v1, const Vec &v2) ;
  friend Point operator +(const Vec &v1, const Point &v2) ;
  friend Point operator -(const Point &v1, const Vec &v2) ;
  friend Point operator -(const Vec &v1, const Point &v2) ;
  friend Vec   operator -(const Point &p1, const Point &p2) ;

  friend Vec operator *(const Vec &v, int d) ;
  friend Vec operator *(int d, const Vec &v) ;
  friend Vec operator /(const Vec &v, int d) ;
  Vec & operator +=(const Vec &) ;
  Vec & operator -=(const Vec &) ;
  Vec & operator *=(int d) ;
  Vec & operator /=(int d) ;
  Vec operator -() const ;

  friend std::ostream & operator << (std::ostream &strm, const Vec &v) ;

  friend bool operator == (const Vec &v1, const Vec &v2) ;
  friend bool operator != (const Vec &v1, const Vec &v2) ;

  operator cv::Point () ;
  operator cv::Vec2i () ;

  int x, y ;
} ;

#undef max
#undef min

inline Point max(const Point &a, const Point &b)
{
  return Point(std::max(a.x, b.x), std::max(a.y, b.y)) ;   
}

inline Point min(const Point &a, const Point &b)
{
  return Point(std::min(a.x, b.x), std::min(a.y, b.y)) ;   
}

inline Point max(const Point &a, const Point &b, const Point &c)
{
  return max(a, max(b, c)) ;   
}
inline Point min(const Point &a, const Point &b, const Point &c)
{
  return min(a, min(b, c)) ;   
}

inline Point::Point()
{
  x = y = 0 ;
}

inline Point::Point(const Point &v)
{
  *this = v ;
}

inline Point::Point(int x, int y)
{
  Point::x = x ;
  Point::y = y ;
}

inline Point::Point(const cv::Point &v)
{
    x = v.x ;
    y = v.y ;
}

inline Point::Point(const cv::Vec2i &v)
{
    x = v[0] ;
    y = v[1] ;
}

inline Point & Point::operator +=(const Vec &v) 
{
  x += v.x ;
  y += v.y ;

  return *this ;
}

inline Point & Point::operator -=(const Vec &v)
{
  x -= v.x ;
  y -= v.y ;

  return *this ;
}
  
inline std::ostream & operator << (std::ostream &strm, const Point &v)
{
  return strm << "( " << v.x << " , " << v.y << " )" ;
}

inline bool operator == (const Point &v1, const Point &v2)
{
  return (v1.x == v2.x && v1.y == v2.y ) ;
}

inline bool operator != (const Point &v1, const Point &v2)
{
  return !(v1 == v2) ;
}


inline Point::operator cv::Point ()  {
    return cv::Point(x, y) ;
}

inline Point::operator cv::Vec2i ()  {
    return cv::Vec2i(x, y) ;
}

inline Vec::Vec()
{
  x = y = 0 ;
}

inline Vec::Vec(const Vec &v)
{
  *this = v ;
}

inline Vec::Vec(int x, int y)
{
  Vec::x = x ;
  Vec::y = y ;
}

inline Vec::Vec(const cv::Point &v)
{
    x = v.x ;
    y = v.y ;
}

inline Vec::Vec(const cv::Vec2i &v)
{
    x = v[0] ;
    y = v[1] ;
}

inline Vec::Vec(const Point &p1, const Point &p2)
{
  x = p2.x - p1.x ;
  y = p2.y - p1.y ;
}

inline Point operator +(const Point &v1, const Vec &v2)
{
  return Point(v1.x + v2.x, v1.y + v2.y) ;
}

inline Point operator +(const Vec &v1, const Point &v2)
{
  return Point(v1.x + v2.x, v1.y + v2.y) ;
}

inline Point operator -(const Point &v1, const Vec &v2)
{
  return Point(v1.x - v2.x, v1.y - v2.y) ;
}

inline Point operator -(const Vec &v1, const Point &v2)
{
  return Point(v1.x - v2.x, v1.y - v2.y) ;
}

inline Vec operator -(const Point &v1, const Point &v2)
{
  return Vec(v2, v1) ;
}

inline Vec operator *(const Vec &v, int d)
{
  return Vec(v.x * d, v.y * d) ;
}

inline Vec operator *(int d, const Vec &v)
{
  return Vec(v.x * d, v.y * d) ;
}

inline Vec operator /(const Vec &v, int d)
{
  assert( d != 0 ) ;
  return Vec(v.x / d, v.y / d) ;
}

inline Vec & Vec::operator +=(const Vec &v) 
{
  x += v.x ;
  y += v.y ;

  return *this ;
}

inline Vec & Vec::operator -=(const Vec &v)
{
  x -= v.x ;
  y -= v.y ;

  return *this ;
}
  
inline Vec & Vec::operator *=(int d) 
{
  x *= d ;
  y *= d ;

  return *this ;
}

inline Vec & Vec::operator /=(int d) 
{
  assert( d != 0 ) ;

  x /= d ;
  y /= d ;

  return *this ;
}

inline Vec Vec::operator -() const 
{
  return Vec(-x, -y) ;
}

inline std::ostream & operator << (std::ostream &strm, const Vec &v)
{
  return strm << "( " << v.x << " , " << v.y << " )" ;
}

inline bool operator == (const Vec &v1, const Vec &v2)
{
  return (v1.x == v2.x && v1.y == v2.y ) ;
}

inline bool operator != (const Vec &v1, const Vec &v2)
{
  return !(v1 == v2) ;
}

inline Vec::operator cv::Point ()  {
    return cv::Point(x, y) ;
}

inline Vec::operator cv::Vec2i ()  {
    return cv::Vec2i(x, y) ;
}

} //namespace cpm ;

#endif

