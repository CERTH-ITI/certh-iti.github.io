#ifndef __VIDEO_GRABBER_H__
#define __VIDEO_GRABBER_H__

#include <certh_core/config.h>


#include <opencv2/opencv.hpp>

namespace certh_core {

#define MAX_VIDEO_CHANNELS 5

class ImageBuffer ;
class CaptureThread ;
class GrabberImpl ;

// Abstract class implementing non-locking multi-threaded video capture

class VideoGrabber
{
protected:

    VideoGrabber(GrabberImpl *grabber) ;

public:
    // start the capture thread
    void start() ;

    // stop the capture thread
    void stop() ;

    // get all recorded channels
    void getFrame(cv::Mat frames[MAX_VIDEO_CHANNELS]) ;

    // get first two recorded channels
    void getFrame(cv::Mat &chn1, cv::Mat &chn2) ;

    // get first recorded channel
    cv::Mat getFrame() ;

    // get current frame rate
    float getFramesPerSec() const ;

    int getFrameWidth() const ;
    int getFrameHeight() const ;

    bool isReady() const ;

    virtual ~VideoGrabber() ;


private:

    ImageBuffer *imageBuffer ;
    CaptureThread *capThread ;

protected:
    GrabberImpl *grabber ;

};

#if HAVE_OPENNI

// Kinect specific grabber
class KinectGrabber: public VideoGrabber
{
    public:

    KinectGrabber(int device=0) ;
    KinectGrabber(const std::string &device) ;

    static cv::Mat colorize(const cv::Mat &depth_data, double minVal = DBL_MAX, double maxVal = DBL_MAX) ;

    float getBaseLine() const ;
    float getFocalLength() const ;

};

#endif

// Video camera grabber
class VideoCameraGrabber: public VideoGrabber
{
    public:

    VideoCameraGrabber(int camid = 0, int resX = -1, int resY = -1, int rate = -1 ) ;
};

// grab from a video file
class VideoFileGrabber: public VideoGrabber
{
public:


    VideoFileGrabber(const char *fileName, double fps = 30) ;
};

// grab from image sequence
class SequenceGrabber: public VideoGrabber
{
public:

// specify sequence in the form /path/xxx[%0xd]xxx[%c]xxxx.ext
// where %0xd  is fprintf format of decimal value for frame numbers (x is the number of digits)
// and %c similarily for a character value representing channel id.
// The constructor takes optionally a null terminated string of of channel chars e.g. "cd" means that it
// will try to replace %c value with 'c' and 'd' and load the associated files

    SequenceGrabber(const char *filePattern, const char *channnels = 0, double fps = 30) ;
};

} // namespace certh_core

#endif
