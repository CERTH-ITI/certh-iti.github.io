#include <iostream>
#include <vector>
#include <opencv2/opencv.hpp>
#include <curl/curl.h>

struct MemoryStruct {
  char *memory;
  size_t size;
};

class certh_ip_camera
{
public:
    certh_ip_camera();
    ~certh_ip_camera();

    bool startGrabber(std::string& url);
    bool grabFrame(cv::Mat& frame, bool flushStream=true, int minDelay=5);
    void stopGrabber();
    bool restartCamera(int tries=0, int sleeptime=1000);
    int grabMotion();
    static size_t write_data(void *contents, size_t size, size_t nmemb, void *userp);

private:
    void flushStreamBuffer();

    cv::VideoCapture vcap_;
    std::string url_;
    cv::Mat BG_;
    CURL* curl_;


};
